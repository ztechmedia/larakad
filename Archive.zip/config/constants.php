<?php

// define('SCHOOL_NAME', 'SDN 1 CIMUNING');

// function setTitle($text) {
//     return SCHOOL_NAME . ' | ' . $text;
// }